from dotenv import load_dotenv, find_dotenv

def load_env():
  _ = load_dotenv(find_dotenv())